﻿using DataAccessLayer.Models;

namespace DataAccessLayer.Repository
{
    public interface ITaskRepository : IRepository<Task>
    {
    }
}
