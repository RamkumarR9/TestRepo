﻿using DataAccessLayer.Models;

namespace DataAccessLayer.Repository
{
    public interface IToDoRepository : IRepository<ToDoItem>
    {
    }
}
