﻿using BusinessLogic;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace ToDoMobileApp.Tests
{
    [ExcludeFromCodeCoverage]
    public sealed class ToDoMockService : IDisposable, IToDoBL
    {
        public Domain.Models.ToDoItem Add(Domain.Models.ToDoItem item)
        {
            throw new Exception("This is mock exception");
        }
        
        public bool Delete(int id)
        {
            throw new Exception("This is mock exception");
        }

        public bool Update(Domain.Models.ToDoItem item)
        {
            throw new Exception("This is mock exception");
        }

        /// <summary>
        /// This is to get all the items
        /// </summary>
        /// <returns>list of items as object</returns>
        public List<Domain.Models.ToDoItem> GetAll()
        {
            throw new Exception("This is mock exception");
        }

        public string GetItemCount()
        {
            throw new Exception("This is mock exception");
        }
        public bool RemoveItem()
        {
            throw new Exception("This is mock exception");
        }

        public void Dispose()
        {
            //Nothing to do
        }
    }
}
