﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ToDoMobileApp.Util
{
    public sealed class Handler
    {
        private Handler()
        {

        }

        public static void HandlerException()
        {
            HttpContext context = HttpContext.Current;
            context.Response.Write("<script type='text/javascript'>");

            context.Response.Write("window.location = '/Error'</script>");
            //   Redirect("")
            //   HttpContext.Current.Response.RedirectToRoute("Error");
            //  HttpContext.Response.Redirect("Error");
        }

        public static void HandlerFinally()
        {
            
        }
    }
}