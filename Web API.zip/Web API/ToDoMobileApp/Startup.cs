﻿using Microsoft.Owin;
using Owin;
using System.Diagnostics.CodeAnalysis;

[assembly: OwinStartup(typeof(ToDoMobileApp.Startup))]

namespace ToDoMobileApp
{
    public partial class Startup
    {
        [ExcludeFromCodeCoverage]
        public void Configuration(IAppBuilder app)
        {
            ConfigureMobileApp(app);
        }
    }
}